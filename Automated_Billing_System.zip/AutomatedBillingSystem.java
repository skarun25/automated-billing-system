import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AutomatedBillingSystem {
    static class Item {
        String name;
        int quantity;
        double price;

        Item(String name, int quantity, double price) {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }

        double amount() {
            return quantity * price;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Item> items = new ArrayList<>();

        System.out.println("==================================");
        System.out.println("      AUTOMATED BILLING SYSTEM");
        System.out.println("==================================");

        System.out.print("Enter customer name: ");
        String customerName = sc.nextLine();

        String choice;
        do {
            System.out.print("\\nEnter item name: ");
            String name = sc.nextLine();

            System.out.print("Enter quantity: ");
            int quantity = readPositiveInt(sc);

            System.out.print("Enter price per item (Rs.): ");
            double price = readNonNegativeDouble(sc);

            items.add(new Item(name, quantity, price));

            System.out.print("Add another item? (yes/no): ");
            choice = sc.nextLine().trim().toLowerCase();
        } while (choice.equals("yes") || choice.equals("y"));

        double subtotal = 0;
        System.out.println("\\n============== CUSTOMER BILL ==============");
        System.out.println("Customer: " + customerName);
        System.out.println("-------------------------------------------");
        System.out.printf("%-18s %5s %10s %12s%n",
                "Item", "Qty", "Price", "Amount");
        System.out.println("-------------------------------------------");

        for (Item item : items) {
            System.out.printf("%-18s %5d %10.2f %12.2f%n",
                    item.name, item.quantity, item.price, item.amount());
            subtotal += item.amount();
        }

        double gstRate = 0.05; // Example GST rate: 5%
        double gst = subtotal * gstRate;
        double total = subtotal + gst;

        System.out.println("-------------------------------------------");
        System.out.printf("%-35s Rs. %8.2f%n", "Subtotal:", subtotal);
        System.out.printf("%-35s Rs. %8.2f%n", "GST (5%):", gst);
        System.out.printf("%-35s Rs. %8.2f%n", "Grand Total:", total);
        System.out.println("===========================================");
        System.out.println("         Thank you for shopping!");
        System.out.println("===========================================");

        sc.close();
    }

    private static int readPositiveInt(Scanner sc) {
        while (true) {
            try {
                int value = Integer.parseInt(sc.nextLine().trim());
                if (value > 0) return value;
            } catch (NumberFormatException ignored) {
                // Ask again below.
            }
            System.out.print("Please enter a whole number greater than 0: ");
        }
    }

    private static double readNonNegativeDouble(Scanner sc) {
        while (true) {
            try {
                double value = Double.parseDouble(sc.nextLine().trim());
                if (Double.isFinite(value) && value >= 0) return value;
            } catch (NumberFormatException ignored) {
                // Ask again below.
            }
            System.out.print("Please enter a valid price (0 or more): ");
        }
    }
}
