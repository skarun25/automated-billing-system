AUTOMATED BILLING SYSTEM - JAVA

Files:
- AutomatedBillingSystem.java : Java source code

Requirements:
- Java JDK 8 or later

How to run:
1. Extract this ZIP file.
2. Open a terminal/command prompt in the extracted folder.
3. Compile:
   javac AutomatedBillingSystem.java
4. Run:
   java AutomatedBillingSystem

Features:
- Takes customer name.
- Accepts multiple items, quantity, and unit price.
- Calculates each item amount and subtotal.
- Adds an example 5% GST and displays the grand total.

Note:
The 5% GST is only an example for a college project. Change gstRate in the
source code if your assignment requires a different rate. This is a simple
console-based project; it does not save bills to a database or print receipts.
